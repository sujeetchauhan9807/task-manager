<?php $__env->startPush('styles'); ?>
<?php echo app('Illuminate\Foundation\Vite')('resources/css/custom-table.css'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<div class="py-12">

    <script>
        <?php if(session('success')): ?>
        toastr.success("<?php echo e(session('success')); ?>");
        <?php endif; ?>
    </script>

    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

        <div class="table-container">


            <div class="top-section">

                <form action="<?php echo e(route('dashboard')); ?>"
                    method="GET"
                    class="filter-form">


                    <input type="text"
                        name="search"
                        placeholder="Search task..."
                        value="<?php echo e(request('search')); ?>"
                        class="form-control">


                    <select name="status" class="form-control">

                        <option value="">
                            All Status
                        </option>

                        <option value="pending"
                            <?php echo e(request('status') == 'pending' ? 'selected' : ''); ?>>
                            Pending
                        </option>

                        <option value="completed"
                            <?php echo e(request('status') == 'completed' ? 'selected' : ''); ?>>
                            Completed
                        </option>

                    </select>


                    <button type="submit" class="btn btn-primary">
                        Filter
                    </button>

                    &nbsp;&nbsp;&nbsp;
                    <a href="<?php echo e(route('dashboard')); ?>">
                        <button type="button" class="btn btn-secondary">
                            Reset
                        </button>
                    </a>

                </form>

            </div>

            <br>
            <table>

                <thead>

                    <tr>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Status</th>
                        <th>Due Date</th>
                        <th width="180">Action</th>
                    </tr>

                </thead>

                <tbody>

                    <?php if($tasks->isEmpty()): ?>

                    <tr>
                        <td colspan="5" style="text-align:center;">
                            No tasks found.
                        </td>
                    </tr>

                    <?php endif; ?>

                    <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>

                        <td data-label="Title">
                            <?php echo e($task->title); ?>

                        </td>


                        <td data-label="Description">
                            <?php echo e($task->description); ?>

                        </td>


                        <td data-label="Status">

                            <?php if($task->status == 'pending'): ?>

                            <span class="badge pending-badge">
                                Pending
                            </span>

                            <?php else: ?>

                            <span class="badge completed-badge">
                                Completed
                            </span>

                            <?php endif; ?>

                        </td>


                        <td data-label="Due Date">
                            <?php echo e($task->due_date); ?>

                        </td>
                        <td data-label="Action">
                            <a href="<?php echo e(route('tasks.edit', $task->id)); ?>">
                                <button class="btn btn-primary">
                                    <i class="fa fa-edit" style="font-size:28px"></i>
                                </button>
                            </a> &nbsp;&nbsp;
                            <form action="<?php echo e(route('tasks.destroy', $task->id)); ?>"
                                method="POST"
                                style="display:inline;">

                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>

                                <button type="submit"
                                    class="btn btn-danger"
                                    onclick="return confirm('Are you sure you want to delete this task?')">

                                    <i class="fa fa-trash" style="font-size:28px"></i>

                                </button>

                            </form>

                        </td>

                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>

            </table>


            <div class="pagination-wrapper">

                <?php echo e($tasks->appends(request()->query())->links()); ?>


            </div>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\task-manager\resources\views/dashboard.blade.php ENDPATH**/ ?>