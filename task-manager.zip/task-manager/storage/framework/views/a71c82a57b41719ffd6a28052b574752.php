

<?php $__env->startSection('content'); ?>

<div class="container">

    <div class="card">

        <h2>Multiple File Upload</h2>

        <form id="uploadForm" enctype="multipart/form-data">

            <?php echo csrf_field(); ?>

            <div class="form-group">

                <input type="file"
                    name="files[]"
                    id="files"
                    multiple>

            </div>

            
            <div id="preview-container"></div>

            <button type="submit"
                class="btn btn-primary">

                Upload Files

            </button>

        </form>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/js/jquery.js', 'resources/js/ajax/upload.js']); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\task-manager\resources\views\file-upload.blade.php ENDPATH**/ ?>