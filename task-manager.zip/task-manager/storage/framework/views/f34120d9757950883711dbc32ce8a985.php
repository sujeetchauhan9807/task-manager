
<?php $__env->startPush('styles'); ?>
<?php echo app('Illuminate\Foundation\Vite')('resources/css/custom-form.css'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="py-12">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="page-center">
            <div class="container">
                <form id="uploadForm" enctype="multipart/form-data">
                    <div class="card">
                        <h2>Multiple File Upload</h2>
                        <div class="form-group">
                            <?php echo csrf_field(); ?>
                            <label>File</label>
                            <input type="file" name="files[]" id="files" multiple placeholder="Enter task title">

                        </div>

                        <div class="form-group">
                            <label>Preview</label>
                            <div id="preview-container"></div>
                        </div>

                        <button type="submit" class="btn btn-primary submit-btn">Upload Files</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/js/jquery.js', 'resources/js/ajax/upload.js']); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\task-manager\resources\views/file-upload.blade.php ENDPATH**/ ?>