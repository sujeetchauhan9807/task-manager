    
    <?php $__env->startPush('styles'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/custom-form.css'); ?>
    <?php $__env->stopPush(); ?>
    <?php $__env->startSection('content'); ?>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="page-center">
                <div class="container">
                    <form id="addTaskForm" data-url="<?php echo e(route('tasks.store')); ?>" method="POST">
                        <div class="card">
                            <h2>Create Task</h2>
                            <div class="form-group">
                                <?php echo csrf_field(); ?>
                                <label>Title</label>
                                <input type="text" name="title" placeholder="Enter task title">
                                <span class="text-danger" id="error-msg-title" style="color:red"></span>
                            </div>

                            <div class="form-group">
                                <label>Description</label>
                                <textarea name="description" placeholder="Enter task description"></textarea>
                                <span class="text-danger" id="error-msg-description" style="color:red"></span>
                            </div>

                            <div class="form-group">
                                <label>Due Date</label>
                                <input type="date" name="due_date" min="<?php echo e(date('Y-m-d')); ?>">
                                <span class="text-danger" id="error-msg-due_date" style="color:red"></span>
                            </div>
                            <button type="submit" class="btn btn-primary submit-btn">Create Task</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
    <?php $__env->startPush('scripts'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/jquery.js', 'resources/js/ajax/add-task.js']); ?>
    <?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\task-manager\resources\views/task.blade.php ENDPATH**/ ?>