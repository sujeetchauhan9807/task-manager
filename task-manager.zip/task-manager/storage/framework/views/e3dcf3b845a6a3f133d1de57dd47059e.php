

<?php $__env->startPush('styles'); ?>
<?php echo app('Illuminate\Foundation\Vite')('resources/css/custom-form.css'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<div class="py-12">

    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

        <div class="page-center">

            <div class="container">

                <form action="<?php echo e(route('tasks.update', $task->id)); ?>"
                    method="POST">

                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="card">

                        <h2>Edit Task</h2>

                        
                        <div class="form-group">

                            <label>Title</label>

                            <input type="text"
                                name="title"
                                placeholder="Enter task title"
                                value="<?php echo e(old('title', $task->title)); ?>">

                            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger" style="color:red;">
                                <?php echo e($message); ?>

                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>

                        
                        <div class="form-group">

                            <label>Description</label>

                            <textarea name="description"
                                placeholder="Enter task description"><?php echo e(old('description', $task->description)); ?></textarea>

                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger" style="color:red;">
                                <?php echo e($message); ?>

                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>

                        
                        <div class="form-group">

                            <label>Status</label>

                            <select name="status">

                                <option value="pending"
                                    <?php echo e(old('status', $task->status) == 'pending' ? 'selected' : ''); ?>>

                                    Pending

                                </option>

                                <option value="completed"
                                    <?php echo e(old('status', $task->status) == 'completed' ? 'selected' : ''); ?>>

                                    Completed

                                </option>

                            </select>

                            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger" style="color:red;">
                                <?php echo e($message); ?>

                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>

                        
                        <div class="form-group">

                            <label>Due Date</label>

                            <input type="date"
                                name="due_date"
                                min="<?php echo e(date('Y-m-d')); ?>"
                                value="<?php echo e(old('due_date', $task->due_date)); ?>">

                            <?php $__errorArgs = ['due_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger" style="color:red;">
                                <?php echo e($message); ?>

                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>

                        
                        <div style="display:flex; gap:10px;">

                            <button type="submit"
                                class="btn btn-primary submit-btn">

                                Update Task

                            </button>
                        </div>

                    </div>

                </form>

            </div>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\task-manager\resources\views/edit.blade.php ENDPATH**/ ?>