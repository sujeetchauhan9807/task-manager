<?php

namespace App\Http\Controllers;

use App\Models\File;
use Illuminate\Http\Request;

class FileController extends Controller
{
    public function index()
    {
        return view('file-upload');
    }
    public function upload(Request $request)
    {
        $request->validate([

            'files.*' => 'required|mimes:jpg,jpeg,png,pdf|max:2048'

        ]);

        $uploadedFiles = [];

        if ($request->hasFile('files')) {

            foreach ($request->file('files') as $file) {

                $path = $file->store('uploads', 'public');

                $uploadedFiles[] = File::create([

                    'file_name' => $file->getClientOriginalName(),

                    'file_path' => $path,

                    'user_id' => auth()->id()

                ]);
            }
        }

        return response()->json([

            'success' => true,

            'message' => 'Files uploaded successfully',

            'files' => $uploadedFiles

        ]);
    }
}
