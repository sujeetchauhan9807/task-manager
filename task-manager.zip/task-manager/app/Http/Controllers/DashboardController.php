<?php

namespace App\Http\Controllers;

use App\Models\Task;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index(Request $request)
    {
        $query = Task::where('user_id', auth()->id());

        if ($request->search) {
            $query->where('title', 'like', '%' . $request->search . '%');
        }

        if ($request->status) {
            $query->where('status', $request->status);
        }

        $totalTasks = Task::where('user_id', auth()->id())->count();

        $pendingTasks = Task::where('user_id', auth()->id())
            ->where('status', 'pending')
            ->count();

        $completedTasks = Task::where('user_id', auth()->id())
            ->where('status', 'completed')
            ->count();

        $tasks = $query->latest()->paginate(5);

        return view('dashboard', compact(
            'tasks',
            'totalTasks',
            'pendingTasks',
            'completedTasks'
        ));
    }
}
