@extends('layouts.app')
@push('styles')
@vite('resources/css/custom-form.css')
@endpush
@section('content')
<div class="py-12">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="page-center">
            <div class="container">
                <form id="uploadForm" enctype="multipart/form-data">
                    <div class="card">
                        <h2>Multiple File Upload</h2>
                        <div class="form-group">
                            @csrf
                            <label>File</label>
                            <input type="file" name="files[]" id="files" multiple placeholder="Enter task title">

                        </div>

                        <div class="form-group">
                            <label>Preview</label>
                            <div id="preview-container"></div>
                        </div>

                        <button type="submit" class="btn btn-primary submit-btn">Upload Files</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
@push('scripts')
@vite(['resources/js/jquery.js', 'resources/js/ajax/upload.js'])
@endpush