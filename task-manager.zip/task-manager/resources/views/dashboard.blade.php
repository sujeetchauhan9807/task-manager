@extends('layouts.app')

@push('styles')
@vite('resources/css/custom-table.css')
@endpush

@section('content')

<div class="py-12">

    <script>
        @if(session('success'))
        toastr.success("{{ session('success') }}");
        @endif
    </script>

    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

        <div class="table-container">


            <div class="top-section">

                <form action="{{ route('dashboard') }}"
                    method="GET"
                    class="filter-form">


                    <input type="text"
                        name="search"
                        placeholder="Search task..."
                        value="{{ request('search') }}"
                        class="form-control">


                    <select name="status" class="form-control">

                        <option value="">
                            All Status
                        </option>

                        <option value="pending"
                            {{ request('status') == 'pending' ? 'selected' : '' }}>
                            Pending
                        </option>

                        <option value="completed"
                            {{ request('status') == 'completed' ? 'selected' : '' }}>
                            Completed
                        </option>

                    </select>


                    <button type="submit" class="btn btn-primary">
                        Filter
                    </button>

                    &nbsp;&nbsp;&nbsp;
                    <a href="{{ route('dashboard') }}">
                        <button type="button" class="btn btn-secondary">
                            Reset
                        </button>
                    </a>

                </form>

            </div>

            <br>
            <table>

                <thead>

                    <tr>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Status</th>
                        <th>Due Date</th>
                        <th width="180">Action</th>
                    </tr>

                </thead>

                <tbody>

                    @if ($tasks->isEmpty())

                    <tr>
                        <td colspan="5" style="text-align:center;">
                            No tasks found.
                        </td>
                    </tr>

                    @endif

                    @foreach($tasks as $task)

                    <tr>

                        <td data-label="Title">
                            {{ $task->title }}
                        </td>


                        <td data-label="Description">
                            {{ $task->description }}
                        </td>


                        <td data-label="Status">

                            @if($task->status == 'pending')

                            <span class="badge pending-badge">
                                Pending
                            </span>

                            @else

                            <span class="badge completed-badge">
                                Completed
                            </span>

                            @endif

                        </td>


                        <td data-label="Due Date">
                            {{ $task->due_date }}
                        </td>
                        <td data-label="Action">
                            <a href="{{ route('tasks.edit', $task->id) }}">
                                <button class="btn btn-primary">
                                    <i class="fa fa-edit" style="font-size:28px"></i>
                                </button>
                            </a> &nbsp;&nbsp;
                            <form action="{{ route('tasks.destroy', $task->id) }}"
                                method="POST"
                                style="display:inline;">

                                @csrf
                                @method('DELETE')

                                <button type="submit"
                                    class="btn btn-danger"
                                    onclick="return confirm('Are you sure you want to delete this task?')">

                                    <i class="fa fa-trash" style="font-size:28px"></i>

                                </button>

                            </form>

                        </td>

                    </tr>

                    @endforeach

                </tbody>

            </table>


            <div class="pagination-wrapper">

                {{ $tasks->appends(request()->query())->links() }}

            </div>

        </div>

    </div>

</div>

@endsection