    @extends('layouts.app')
    @push('styles')
    @vite('resources/css/custom-form.css')
    @endpush
    @section('content')
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="page-center">
                <div class="container">
                    <form id="addTaskForm" data-url="{{ route('tasks.store') }}" method="POST">
                        <div class="card">
                            <h2>Create Task</h2>
                            <div class="form-group">
                                @csrf
                                <label>Title</label>
                                <input type="text" name="title" placeholder="Enter task title">
                                <span class="text-danger" id="error-msg-title" style="color:red"></span>
                            </div>

                            <div class="form-group">
                                <label>Description</label>
                                <textarea name="description" placeholder="Enter task description"></textarea>
                                <span class="text-danger" id="error-msg-description" style="color:red"></span>
                            </div>

                            <div class="form-group">
                                <label>Due Date</label>
                                <input type="date" name="due_date" min="{{ date('Y-m-d') }}">
                                <span class="text-danger" id="error-msg-due_date" style="color:red"></span>
                            </div>
                            <button type="submit" class="btn btn-primary submit-btn">Create Task</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    @endsection
    @push('scripts')
    @vite(['resources/js/jquery.js', 'resources/js/ajax/add-task.js'])
    @endpush