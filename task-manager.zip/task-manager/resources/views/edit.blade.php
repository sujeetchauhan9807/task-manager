@extends('layouts.app')

@push('styles')
@vite('resources/css/custom-form.css')
@endpush

@section('content')

<div class="py-12">

    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

        <div class="page-center">

            <div class="container">

                <form action="{{ route('tasks.update', $task->id) }}"
                    method="POST">

                    @csrf
                    @method('PUT')

                    <div class="card">

                        <h2>Edit Task</h2>

                        {{-- Title --}}
                        <div class="form-group">

                            <label>Title</label>

                            <input type="text"
                                name="title"
                                placeholder="Enter task title"
                                value="{{ old('title', $task->title) }}">

                            @error('title')
                            <span class="text-danger" style="color:red;">
                                {{ $message }}
                            </span>
                            @enderror

                        </div>

                        {{-- Description --}}
                        <div class="form-group">

                            <label>Description</label>

                            <textarea name="description"
                                placeholder="Enter task description">{{ old('description', $task->description) }}</textarea>

                            @error('description')
                            <span class="text-danger" style="color:red;">
                                {{ $message }}
                            </span>
                            @enderror

                        </div>

                        {{-- Status --}}
                        <div class="form-group">

                            <label>Status</label>

                            <select name="status">

                                <option value="pending"
                                    {{ old('status', $task->status) == 'pending' ? 'selected' : '' }}>

                                    Pending

                                </option>

                                <option value="completed"
                                    {{ old('status', $task->status) == 'completed' ? 'selected' : '' }}>

                                    Completed

                                </option>

                            </select>

                            @error('status')
                            <span class="text-danger" style="color:red;">
                                {{ $message }}
                            </span>
                            @enderror

                        </div>

                        {{-- Due Date --}}
                        <div class="form-group">

                            <label>Due Date</label>

                            <input type="date"
                                name="due_date"
                                min="{{ date('Y-m-d') }}"
                                value="{{ old('due_date', $task->due_date) }}">

                            @error('due_date')
                            <span class="text-danger" style="color:red;">
                                {{ $message }}
                            </span>
                            @enderror

                        </div>

                        {{-- Buttons --}}
                        <div style="display:flex; gap:10px;">

                            <button type="submit"
                                class="btn btn-primary submit-btn">

                                Update Task

                            </button>
                        </div>

                    </div>

                </form>

            </div>

        </div>

    </div>

</div>

@endsection