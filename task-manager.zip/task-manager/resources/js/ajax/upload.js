
    $('#files').on('change', function () {

        $('#preview-container').html('');

        let files = this.files;

        for (let i = 0; i < files.length; i++) {

            let file = files[i];

            let reader = new FileReader();

            // Image Preview
            if (file.type.includes('image')) {

                reader.onload = function (e) {

                    $('#preview-container').append(`

                        <img src="${e.target.result}"
                             width="120"
                             style="margin:10px; border-radius:10px; border:1px solid #ddd;">

                    `);

                }

                reader.readAsDataURL(file);

            }

            else if (file.type == 'application/pdf') {

                $('#preview-container').append(`

                    <div style="
                        padding:10px;
                        margin:10px;
                        border:1px solid #ddd;
                        border-radius:10px;
                        display:inline-block;
                    ">

                        📄 ${file.name}

                    </div>

                `);

            }

        }

    });

    // AJAX Upload
    $('#uploadForm').submit(function (e) {

        e.preventDefault();

        let formData = new FormData(this);

        $.ajax({

            url: "upload",

            type: "POST",

            data: formData,

            processData: false,

            contentType: false,

            success: function (response) {

                toastr.success(response.message);

                $('#uploadForm')[0].reset();

                $('#preview-container').html('');

            },

            error: function (xhr) {

                // console.log(xhr.responseText);
                let errors = xhr.responseJSON.errors;
                $.each(errors, function (key, value) {
                    toastr.warning(value[0]);
                });
            }

        });

    });

