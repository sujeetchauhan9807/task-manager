
$(document).ready(function () {
    $('#addTaskForm').on('submit', function (event) {
        event.preventDefault();
        let TASK_STORE_URL = $('#addTaskForm').data('url');
        $.ajax({
            url: TASK_STORE_URL, 
            type: "POST",
            data: new FormData(this),
            cache: false,
            processData: false,
            contentType: false,
            beforeSend: function () {
                $(".submit-btn").val("Submitting...").prop("disabled", true);
            },

            success: function (response) {
                console.log(response.message);
                $(".text-danger").html('');
                toastr.success(response.message);
                $('#addTaskForm')[0].reset();
            },

            error: function (xhr) {
                let errors = xhr.responseJSON.errors;
                $(".text-danger").html('');
                $.each(errors, function (field, messages) {
                    $("#error-msg-" + field).html(messages[0]);
                });
            },

            complete: function () {
                $(".submit-btn").val("Submit").prop("disabled", false);
            }
        });

    });

});